/**
 * 不保存到 Git 仓库的秘密文件
 */
exports.vod = {
  accessKeyId: 'LTAI4GBDnU3uNnaPhArWbAXa',
  accessKeySecret: 'hup32yUztg6NxtzHkhXpw12OlyX4TP'
}
