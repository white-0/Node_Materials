// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportSubscription = require('../../../app/model/subscription');
import ExportUser = require('../../../app/model/user');
import ExportVideo = require('../../../app/model/video');
import ExportVideoComment = require('../../../app/model/video_comment');
import ExportVideoLike = require('../../../app/model/video_like');
import ExportVideoView = require('../../../app/model/video_view');

declare module 'egg' {
  interface IModel {
    Subscription: ReturnType<typeof ExportSubscription>;
    User: ReturnType<typeof ExportUser>;
    Video: ReturnType<typeof ExportVideo>;
    VideoComment: ReturnType<typeof ExportVideoComment>;
    VideoLike: ReturnType<typeof ExportVideoLike>;
    VideoView: ReturnType<typeof ExportVideoView>;
  }
}
