<template>
  <!-- 根组件路由出口 -->
  <router-view/>
</template>
